rootProject.name = "smp-bridge-plugins"
include("velocity", "paper")
