# SMPBridge plugins (Velocity + Paper)

Two small plugins that connect your **Velocity proxies** (India, Singapore) and your **Paper backend** to the
Discord bot. They dial *out* to the bot over WebSocket, so your game hosts don't need any open port.

| | Velocity plugin (one per proxy) | Paper plugin (backend) |
|---|---|---|
| Live **console** → Discord | ✅ proxy console | ✅ Paper console (anticheat output lands here) |
| **Chat** + **join/leave** | ✅ every backend, both directions | optional (off by default → no duplicates) |
| **Real player ping** + client + loader | ✅ (proxy ping = the player's real ping) | client brand / loader (ping off) |
| Staff **/ban /kick /mute /warn /unban** | ✅ commands typed on the proxy | ✅ console commands (+ optional in-game) |
| Run **console commands from Discord** | ✅ `@in cmd` / `@sg cmd` | ✅ plain commands |
| **Anticheat → punishment log** | `/smpbridge alert|punish …` | `/smpbridge alert|punish …` + console lines |
| **Death log** (exact coords + biome, `Void` if they fell out) | – | ✅ → `#death-logs` |
| Status page extras | player count + avg player ping per proxy | TPS |

## 1. Build the jars on GitHub (nothing to install, works from a phone)

1. github.com → **New repository** (private is fine) → name it `smp-bridge-plugins` → **Create**.
2. In the repo: **Add file → Upload files** → pick **`smp-bridge-plugins.zip`** itself (do *not* unzip it) → **Commit changes**.
3. **Add file → Create new file** → in the name box type `.github/workflows/build.yml` (typing the slashes makes the folders) →
   paste the contents of `build.yml` (it is inside the zip at `.github/workflows/build.yml`; also given in the chat) → **Commit changes**.
   *(On a computer you can instead unzip and upload the whole folder — the workflow file is already inside.)*
4. Open the **Actions** tab → *Build SMPBridge plugins* → wait 2-3 min for the green tick → open the run →
   **Artifacts → SMPBridge-plugins** → it downloads a zip with:
   * `SMPBridge-Paper.jar` → your Paper server
   * `SMPBridge-Velocity-for-3.x.jar` → proxies running Velocity **3.x**
   * `SMPBridge-Velocity-for-4.x.jar` → proxies running Velocity **4.x** (only appears if that build succeeded)
   Not sure which Velocity you run? Type `version` in the proxy console - it prints e.g. `Velocity 3.4.0` or `Velocity 4.x`.
5. Upload the jars into each server's `plugins/` folder (panel → Files → plugins → Upload), **restart** the server, and the plugin
   writes its config file. Continue with step 2 below.

If the run is red: open it, tap the failed step and send me the last 20 lines.

**Updating later:** replace `smp-bridge-plugins.zip` in the repo with the new one (Upload files, same name) → it rebuilds automatically.

*Building locally instead:* JDK 25 + Gradle 9 → `gradle build`; jars appear in `velocity/build/libs` and `paper/build/libs`.
For Velocity 4.x set `velocityApiVersion=4.2.1-SNAPSHOT` and `velocityJavaRelease=25` in `gradle.properties`.

## 2. Connect them

1. Start the Discord bot, run **`/bridge info`** → it shows `bot-url` and `token` (only you can see it).
2. Drop the jars in each server's `plugins/` folder and start once (config files are created):
   * **Velocity India:** `plugins/smpbridge/config.properties` → `id=in`
   * **Velocity Singapore:** same file on that proxy → `id=sg`
   * **Paper:** `plugins/SMPBridge/config.yml` → `id: smp`
3. Paste the same **`bot-url`** and **`token`** in every config, then `/smpbridge reload` (or restart).
4. Run `/bridge info` again - each plugin shows as connected. Then `/smpbridge test` in a game console: a test alert should
   appear in `#punishment-logs`. `/smpbridge test death` posts a sample death in `#death-logs`.

`bot-url` is `ws://<bot-host-ip>:<bot-port>` (the address your bot host shows for the bot's own server/port).

## 3. Anticheat → punishment log

If your anticheat prints to console, the bot already reads the line (see the bot README). If it can run commands when it
flags or punishes someone, point it at the plugin - the format is the same on Paper and Velocity:

```
smpbridge alert  %player% AutoTotem %vl%  client:%client% loader:%loader% ping:%ping% by:AutoTotem
smpbridge punish ban %player% by:AutoTotem dur:perm AutoTotem detected
```
`key:value` options may come in any order (underscores = spaces); anything left over is the reason. Unknown placeholders
(`%vl%` that your anticheat doesn't fill in) are ignored. If you leave `client:` / `loader:` / `ping:` out, the bot fills them
in from what the plugins already know about the player.

## 4. Safety defaults

* A token is required; only commands on `watch-commands` (ban, kick, mute, warn …) are ever forwarded - `/login`, `/msg` etc. never leave the server.
* A **player's** punishment command is forwarded only if they have the permission `smpbridge.staff`
  (so nobody can forge log entries by typing `/ban` without rights). Give your staff that permission in LuckPerms,
  or set `watch-require-permission=` empty to disable the check. Console commands are always trusted.
* The link is plain `ws://`. If the bot is behind HTTPS/Cloudflare, use a `wss://` URL - the plugins support it.

## Protocol (for your own tools)
JSON text frames. Plugin→bot: `hello{token,id,kind,version,feat}`, `console{lines}`, `chat`, `join`, `leave`,
`command{by,cmd}`, `players{online,max,tps,list[]}`, `alert`, `punish`, `goodbye`. Bot→plugin: `ready`, `chat{name,message}`,
`command{cmd,by}`, `ping`.
