package dev.smpbridge.velocity;

import com.google.inject.Inject;
import com.velocitypowered.api.command.CommandMeta;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.event.player.PlayerChatEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.scheduler.ScheduledTask;
import dev.smpbridge.common.BridgeClient;
import dev.smpbridge.common.BridgeCommands;
import dev.smpbridge.common.ClientInfo;
import dev.smpbridge.common.LogForwarder;
import dev.smpbridge.common.Watch;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.slf4j.Logger;

@Plugin(
    id = "smpbridge",
    name = "SMPBridge",
    version = "1.0.0",
    description = "Connects this Velocity proxy to the SMP Discord bridge bot",
    authors = {"SMPBridge"}
)
public final class SmpBridgeVelocity {
    private static final String VERSION = "1.0.0";

    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDir;

    private Config cfg;
    private BridgeClient client;
    private LogForwarder logs;
    private ScheduledTask snapshotTask;
    private final Set<UUID> joined = ConcurrentHashMap.newKeySet();

    @Inject
    public SmpBridgeVelocity(ProxyServer proxy, Logger logger, @DataDirectory Path dataDir) {
        this.proxy = proxy;
        this.logger = logger;
        this.dataDir = dataDir;
    }

    /* ------------------------------ lifecycle ------------------------------ */

    @Subscribe
    public void onInit(ProxyInitializeEvent event) {
        CommandMeta meta = proxy.getCommandManager().metaBuilder("smpbridge").plugin(this).build();
        proxy.getCommandManager().register(meta, new BridgeCommand());
        startBridge();
    }

    @Subscribe
    public void onShutdown(ProxyShutdownEvent event) {
        stopBridge();
    }

    private void startBridge() {
        cfg = Config.load(dataDir, logger);
        if (!cfg.valid()) {
            logger.warn("SMPBridge is not configured yet: edit {} (bot-url + token), then run /smpbridge reload.",
                dataDir.resolve("config.properties"));
            return;
        }
        List<String> features = new ArrayList<>();
        if (cfg.forwardConsole) features.add("console");
        if (cfg.forwardChat) features.add("chat");
        if (cfg.forwardJoins) features.add("join");

        client = new BridgeClient(cfg.url, cfg.token, cfg.id, "velocity", VERSION, features, new Handler(), new BridgeClient.Log() {
            @Override public void info(String message) { logger.info(message); }
            @Override public void warn(String message) { logger.warn(message); }
        });
        if (cfg.forwardConsole) {
            logs = new LogForwarder(client);
            if (!logs.install()) {
                logger.warn("Console forwarding is unavailable on this proxy (log4j not accessible); everything else still works.");
                logs = null;
            }
        }
        client.start();
        snapshotTask = proxy.getScheduler().buildTask(this, this::sendPlayers)
            .delay(5, TimeUnit.SECONDS).repeat(10, TimeUnit.SECONDS).schedule();
    }

    private void stopBridge() {
        if (snapshotTask != null) { snapshotTask.cancel(); snapshotTask = null; }
        if (logs != null) { logs.uninstall(); logs = null; }
        if (client != null) { client.stop(); client = null; }
    }

    /* ------------------------------- bot -> proxy ------------------------------- */

    private final class Handler implements BridgeClient.Handler {
        @Override
        public void onMessage(Map<String, Object> msg) {
            Object t = msg.get("t");
            if ("chat".equals(t)) {
                Component line = Component.text("[Discord] ", NamedTextColor.BLUE)
                    .append(Component.text(String.valueOf(msg.get("name")), NamedTextColor.AQUA))
                    .append(Component.text(" » ", NamedTextColor.GRAY))
                    .append(Component.text(String.valueOf(msg.get("message")), NamedTextColor.WHITE));
                for (Player p : proxy.getAllPlayers()) p.sendMessage(line);
            } else if ("command".equals(t)) {
                String cmd = String.valueOf(msg.get("cmd"));
                logger.info("Console command from Discord ({}): {}", msg.get("by"), cmd);
                proxy.getCommandManager().executeAsync(proxy.getConsoleCommandSource(), cmd);
            }
        }

        @Override public void onConnected() { sendPlayers(); }
        @Override public void onDisconnected() { }
    }

    /* ------------------------------- proxy -> bot ------------------------------- */

    private void sendPlayers() {
        BridgeClient c = client;
        if (c == null || !c.isReady()) return;
        List<Object> list = new ArrayList<>();
        for (Player p : proxy.getAllPlayers()) {
            ClientInfo.Info info = ClientInfo.detect(p.getClientBrand(), null);
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", p.getUsername());
            long ping = p.getPing();
            if (ping >= 0) m.put("ping", ping);
            m.put("client", info.client());
            m.put("loader", info.loader());
            m.put("server", p.getCurrentServer().map(s -> s.getServerInfo().getName()).orElse("-"));
            list.add(m);
        }
        Map<String, Object> msg = new LinkedHashMap<>();
        msg.put("t", "players");
        msg.put("online", list.size());
        msg.put("max", proxy.getConfiguration().getShowMaxPlayers());
        msg.put("list", list);
        c.send(msg);
    }

    @Subscribe
    public void onLogin(PostLoginEvent event) {
        Player p = event.getPlayer();
        joined.add(p.getUniqueId());
        BridgeClient c = client;
        if (c == null) return;
        if (cfg.forwardJoins) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("t", "join");
            m.put("player", p.getUsername());
            c.send(m);
        }
        // the client brand arrives a moment after login
        proxy.getScheduler().buildTask(this, this::sendPlayers).delay(4, TimeUnit.SECONDS).schedule();
    }

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        Player p = event.getPlayer();
        BridgeClient c = client;
        if (!joined.remove(p.getUniqueId()) || c == null || !cfg.forwardJoins) return;
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("t", "leave");
        m.put("player", p.getUsername());
        c.send(m);
    }

    @Subscribe(order = PostOrder.LAST)
    public void onChat(PlayerChatEvent event) {
        BridgeClient c = client;
        if (c == null || !cfg.forwardChat || !event.getResult().isAllowed()) return;
        Player p = event.getPlayer();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("t", "chat");
        m.put("player", p.getUsername());
        m.put("message", event.getMessage());
        m.put("server", p.getCurrentServer().map(s -> s.getServerInfo().getName()).orElse("-"));
        c.send(m);
    }

    /**
     * Staff punishment commands -> Discord. Only the commands on watch-commands are ever forwarded, and a
     * player's command is only forwarded if they hold watch-require-permission (so nobody can forge log entries).
     */
    @Subscribe(order = PostOrder.LAST)
    public void onCommand(CommandExecuteEvent event) {
        BridgeClient c = client;
        if (c == null || !event.getResult().isAllowed() || !Watch.watched(cfg.watch, event.getCommand())) return;
        CommandSource source = event.getCommandSource();
        String by = "Console";
        if (source instanceof Player p) {
            if (!cfg.requirePermission.isEmpty() && !p.hasPermission(cfg.requirePermission)) return;
            by = p.getUsername();
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("t", "command");
        m.put("by", by);
        m.put("cmd", event.getCommand());
        c.send(m);
    }

    /* ------------------------------ /smpbridge ------------------------------ */

    private final class BridgeCommand implements SimpleCommand {
        @Override
        public void execute(Invocation invocation) {
            String reply = run(invocation.arguments());
            invocation.source().sendMessage(Component.text(reply, NamedTextColor.YELLOW));
        }

        @Override
        public boolean hasPermission(Invocation invocation) {
            return invocation.source().hasPermission("smpbridge.admin");
        }
    }

    private String run(String[] args) {
        if (args.length == 0) return "SMPBridge: /smpbridge <status|reload|test|alert|punish>";
        switch (args[0].toLowerCase()) {
            case "status":
                return "SMPBridge " + VERSION + " id=" + (cfg == null ? "?" : cfg.id) + " connected=" + (client != null && client.isReady());
            case "reload":
                stopBridge();
                startBridge();
                return "SMPBridge reloaded.";
            default:
                BridgeCommands.Result r = BridgeCommands.handle(args);
                if (r == null) return "Unknown subcommand. Use status, reload, test, alert or punish.";
                if (r.message == null) return r.reply;
                BridgeClient c = client;
                if (c == null || !c.send(r.message)) return "Not connected to the Discord bot right now.";
                return r.reply;
        }
    }

    /* -------------------------------- config -------------------------------- */

    private static final class Config {
        String url = "";
        String token = "";
        String id = "in";
        boolean forwardConsole = true;
        boolean forwardChat = true;
        boolean forwardJoins = true;
        String requirePermission = "smpbridge.staff";
        Set<String> watch = new HashSet<>(Watch.DEFAULT);

        boolean valid() {
            return !url.isEmpty() && !token.isEmpty() && !token.startsWith("PASTE");
        }

        static Config load(Path dir, Logger logger) {
            Config c = new Config();
            Path file = dir.resolve("config.properties");
            try {
                Files.createDirectories(dir);
                if (!Files.exists(file)) {
                    try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                        w.write(DEFAULT_CONFIG);
                    }
                }
                Properties p = new Properties();
                try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                    p.load(r);
                }
                c.url = p.getProperty("bot-url", "").trim();
                c.token = p.getProperty("token", "").trim();
                c.id = p.getProperty("id", "in").trim();
                c.forwardConsole = Boolean.parseBoolean(p.getProperty("forward-console", "true").trim());
                c.forwardChat = Boolean.parseBoolean(p.getProperty("forward-chat", "true").trim());
                c.forwardJoins = Boolean.parseBoolean(p.getProperty("forward-joins", "true").trim());
                c.requirePermission = p.getProperty("watch-require-permission", "smpbridge.staff").trim();
                c.watch = new HashSet<>(Watch.parseList(p.getProperty("watch-commands", "")));
            } catch (IOException e) {
                logger.error("Could not read the SMPBridge config: {}", e.getMessage());
            }
            return c;
        }

        static final String DEFAULT_CONFIG = String.join("\n",
            "# SMPBridge (Velocity) - run  /bridge info  in Discord to get bot-url and token",
            "bot-url=ws://YOUR_BOT_HOST:PORT",
            "token=PASTE_TOKEN_FROM_/bridge_info",
            "",
            "# a short unique name for THIS proxy: in = India, sg = Singapore",
            "id=in",
            "",
            "forward-console=true",
            "# chat + join/leave are seen by the proxy for every backend server",
            "forward-chat=true",
            "forward-joins=true",
            "",
            "# staff punishment commands forwarded to the punishment log (comma separated, empty = default list)",
            "watch-commands=",
            "# a player's command is only forwarded if they have this permission (stops people forging log entries).",
            "# console commands are always forwarded. Give your staff 'smpbridge.staff' in LuckPerms.",
            "watch-require-permission=smpbridge.staff",
            "");
    }
}
