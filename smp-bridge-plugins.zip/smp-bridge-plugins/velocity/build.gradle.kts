plugins {
    java
}

val velocityApi = providers.gradleProperty("velocityApiVersion").getOrElse("3.4.0-SNAPSHOT")
val javaRelease = providers.gradleProperty("velocityJavaRelease").getOrElse("17").toInt()

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/") { name = "papermc" }
}

dependencies {
    compileOnly("com.velocitypowered:velocity-api:$velocityApi")
    annotationProcessor("com.velocitypowered:velocity-api:$velocityApi")
    compileOnly("org.apache.logging.log4j:log4j-core:2.24.3")
}

// the shared code in ../common is compiled straight into this jar (no extra libraries to install)
sourceSets {
    main {
        java.srcDir("../common/src/main/java")
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(javaRelease)
    options.encoding = "UTF-8"
}

tasks.jar {
    archiveFileName.set("SMPBridge-Velocity.jar")
}
